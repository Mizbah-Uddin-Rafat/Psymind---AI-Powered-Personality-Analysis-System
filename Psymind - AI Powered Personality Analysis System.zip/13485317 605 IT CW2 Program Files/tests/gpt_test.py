from openai import OpenAI
import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer
import numpy as np
from typing import List, Dict, Tuple
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import warnings
warnings.filterwarnings('ignore')

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('punkt')
    nltk.download('stopwords')

from nltk.corpus import stopwords

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="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"
)

# Initialize sentence transformer for semantic similarity
try:
    sentence_model = SentenceTransformer('all-MiniLM-L6-v2')
except:
    sentence_model = None
    print("Warning: SentenceTransformer not available, using TF-IDF fallback")

def generate_optimized_summary(text, personality, emotions, distortions, attempt=1):
    """Advanced prompt engineering with multiple strategies"""
    
    # Strategy 1: Professional clinical format
    if attempt == 1:
        system_prompt = """You are a licensed clinical psychologist with 15+ years experience in personality assessment and CBT. 
        Provide concise, evidence-based analysis using DSM-5 terminology and established psychological frameworks. 
        Focus on specific, measurable traits and concrete therapeutic interventions."""
        
        user_prompt = f"""Clinical Assessment Request:

        Patient Profile:
        - Presenting concerns: {text}
        - Big Five scores: {personality}  
        - Emotional patterns: {emotions}
        - Cognitive distortions: {distortions}

        Provide structured clinical summary:

        **CLINICAL ASSESSMENT**
        - Primary personality dimensions and adaptive/maladaptive patterns
        - Emotional dysregulation indicators and triggers
        - Cognitive distortion severity and functional impact
        
        **TREATMENT RECOMMENDATIONS**
        - Evidence-based interventions (CBT, DBT, ACT protocols)
        - Specific skills training modules required
        - Therapeutic goals and expected outcomes
        
        **VOCATIONAL GUIDANCE**
        List 3 career matches with:
        - Trait-environment fit analysis
        - Strength utilization strategy
        - Challenge mitigation approach
        
        Limit to 250 words. Use clinical terminology."""
    
    # Strategy 2: Structured bullet format
    elif attempt == 2:
        system_prompt = """You are a psychological assessment specialist. Provide structured, bullet-point analysis focusing on clinical precision and professional terminology."""
        
        user_prompt = f"""Assessment Data:
        Text: {text}
        Personality: {personality}
        Emotions: {emotions}
        Distortions: {distortions}

        Format:
        ## PSYCHOLOGICAL PROFILE
        • Personality strengths: [specific Big Five implications]
        • Emotional patterns: [regulation challenges and adaptive capacity]
        • Cognitive patterns: [distortion impact on functioning]
        • Risk/protective factors: [clinical indicators]

        ## INTERVENTIONS
        • CBT targets: [specific distortion work]
        • Skills training: [emotion regulation, distress tolerance]
        • Therapeutic approach: [modality recommendations]

        ## CAREER FIT
        • Role 1: [title] - Personality match and growth areas
        • Role 2: [title] - Strength utilization and support needs  
        • Role 3: [title] - Environmental fit and development path

        Use professional language, 200 words max."""
    
    # Strategy 3: Narrative clinical format
    else:
        system_prompt = """You are writing a clinical case formulation. Use professional psychological language with specific trait references and evidence-based treatment planning."""
        
        user_prompt = f"""Case Formulation Required:

        Client presents with: {text}
        Assessment results: {personality} | {emotions} | {distortions}

        Provide comprehensive formulation addressing:

        PERSONALITY AND EMOTIONAL FUNCTIONING
        Analysis of Big Five profile impact on daily functioning, emotional regulation capacity, and interpersonal patterns. Address specific trait combinations and their clinical implications.

        COGNITIVE PATTERNS AND THERAPEUTIC TARGETS  
        Identification of maladaptive thought patterns, their functional impact, and evidence-based intervention strategies. Include specific CBT protocols and skills training recommendations.

        CAREER AND LIFESTYLE RECOMMENDATIONS
        Three professionally matched roles considering personality-environment fit, utilizing identified strengths while addressing potential challenges through targeted support strategies.

        Professional tone, 220 words maximum."""

    try:
        response = client.chat.completions.create(
            model="openai/gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.1 + (attempt * 0.1),  # Slight variation
            max_tokens=600,
            top_p=0.85,
            frequency_penalty=0.1,
            presence_penalty=0.1
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error: {e}"

def advanced_preprocessing(text: str, mode: str = "semantic") -> str:
    """Advanced preprocessing for different evaluation modes"""
    # Basic cleaning
    text = re.sub(r'[#*•\-\n\r]+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    
    if mode == "semantic":
        # For semantic analysis, keep more context
        text = re.sub(r'[^\w\s\.,;:]', ' ', text)
        # Keep important psychology terms
        psych_terms = ['personality', 'emotional', 'cognitive', 'behavioral', 'therapeutic', 
                      'clinical', 'assessment', 'intervention', 'cbt', 'dbt', 'anxiety', 
                      'depression', 'regulation', 'coping', 'distortion', 'maladaptive']
        words = text.lower().split()
        # Remove common stopwords but keep psychology-relevant terms
        stop_words = set(stopwords.words('english')) - set(psych_terms)
        filtered_words = [w for w in words if w not in stop_words or w in psych_terms]
        return ' '.join(filtered_words)
    
    elif mode == "syntactic":
        # For BLEU/ROUGE, focus on content words
        text = re.sub(r'[^\w\s\.]', ' ', text)
        words = [w.lower() for w in text.split() if len(w) > 2]
        return ' '.join(words)
    
    return text.lower()

def calculate_semantic_similarity_advanced(reference: str, generated: str) -> float:
    """Calculate semantic similarity using sentence transformers if available"""
    if sentence_model is not None:
        try:
            ref_processed = advanced_preprocessing(reference, "semantic")
            gen_processed = advanced_preprocessing(generated, "semantic")
            
            if not ref_processed or not gen_processed:
                return 0.0
            
            # Use sentence transformer embeddings
            embeddings = sentence_model.encode([ref_processed, gen_processed])
            similarity = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]
            return max(0.0, float(similarity))
        except:
            pass
    
    # Fallback to TF-IDF
    try:
        ref_processed = advanced_preprocessing(reference, "semantic")
        gen_processed = advanced_preprocessing(generated, "semantic")
        
        vectorizer = TfidfVectorizer(
            ngram_range=(1, 3), 
            max_features=2000,
            analyzer='word',
            token_pattern=r'\b[a-zA-Z]{2,}\b'
        )
        tfidf_matrix = vectorizer.fit_transform([ref_processed, gen_processed])
        similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        return max(0.0, float(similarity))
    except:
        return 0.0

def calculate_domain_specific_score(reference: str, generated: str) -> float:
    """Calculate domain-specific psychology term overlap"""
    psychology_terms = {
        'personality', 'traits', 'emotional', 'cognitive', 'behavioral', 'therapeutic',
        'clinical', 'assessment', 'intervention', 'therapy', 'cbt', 'dbt', 'anxiety',
        'depression', 'regulation', 'coping', 'distortion', 'maladaptive', 'adaptive',
        'functioning', 'strengths', 'challenges', 'development', 'growth', 'support',
        'neuroticism', 'extraversion', 'openness', 'agreeableness', 'conscientiousness',
        'catastrophizing', 'overgeneralization', 'labeling', 'filtering', 'perfectionism'
    }
    
    ref_words = set(re.findall(r'\b\w+\b', reference.lower()))
    gen_words = set(re.findall(r'\b\w+\b', generated.lower()))
    
    ref_psych = ref_words.intersection(psychology_terms)
    gen_psych = gen_words.intersection(psychology_terms)
    
    if not ref_psych:
        return 1.0 if not gen_psych else 0.0
    
    overlap = len(ref_psych.intersection(gen_psych))
    union = len(ref_psych.union(gen_psych))
    
    return overlap / union if union > 0 else 0.0

def advanced_evaluation(test_cases: List[Dict], reference_summaries: List[str]) -> Dict:
    """Advanced evaluation with multiple strategies and domain-specific metrics"""
    if len(test_cases) != len(reference_summaries):
        raise ValueError("Number of test cases must match number of reference summaries")
    
    all_results = []
    best_summaries = []
    
    print("Advanced LLM Psychological Summary Evaluation")
    print("=" * 80)
    print("Testing multiple generation strategies with domain-specific optimization...")
    print()
    
    for i, (test_case, reference) in enumerate(zip(test_cases, reference_summaries)):
        print(f"Processing case {i+1}/{len(test_cases)}...")
        
        best_score = -1
        best_result = None
        best_summary = ""
        
        # Try 3 different generation strategies
        for strategy in range(1, 4):
            generated = generate_optimized_summary(
                test_case['text'],
                test_case['personality'], 
                test_case['emotions'],
                test_case['distortions'],
                attempt=strategy
            )
            
            # Calculate all metrics
            ref_proc = advanced_preprocessing(reference, "syntactic")
            gen_proc = advanced_preprocessing(generated, "syntactic")
            
            ref_tokens = nltk.word_tokenize(ref_proc)
            gen_tokens = nltk.word_tokenize(gen_proc)
            
            smoothing = SmoothingFunction().method4
            
            # BLEU scores
            bleu1 = sentence_bleu([ref_tokens], gen_tokens, weights=(1,0,0,0), smoothing_function=smoothing)
            bleu2 = sentence_bleu([ref_tokens], gen_tokens, weights=(0.5,0.5,0,0), smoothing_function=smoothing)
            
            # ROUGE scores
            scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
            rouge_scores = scorer.score(ref_proc, gen_proc)
            
            # Advanced semantic similarity
            semantic_sim = calculate_semantic_similarity_advanced(reference, generated)
            
            # Domain-specific score
            domain_score = calculate_domain_specific_score(reference, generated)
            
            # Weighted combined score with domain emphasis
            combined_score = (
                bleu1 * 0.2 +
                rouge_scores['rouge1'].fmeasure * 0.25 +
                rouge_scores['rougeL'].fmeasure * 0.15 +
                semantic_sim * 0.25 +
                domain_score * 0.15  # Psychology-specific terms
            )
            
            if combined_score > best_score:
                best_score = combined_score
                best_summary = generated
                best_result = {
                    'strategy': strategy,
                    'bleu1': bleu1,
                    'bleu2': bleu2,
                    'rouge1_f1': rouge_scores['rouge1'].fmeasure,
                    'rouge2_f1': rouge_scores['rouge2'].fmeasure,
                    'rougeL_f1': rouge_scores['rougeL'].fmeasure,
                    'semantic_similarity': semantic_sim,
                    'domain_score': domain_score,
                    'combined_score': combined_score
                }
        
        all_results.append(best_result)
        best_summaries.append(best_summary)
        
        print(f"  Best Strategy: {best_result['strategy']}")
        print(f"  Combined Score: {best_result['combined_score']:.3f}")
        print(f"  BLEU-1: {best_result['bleu1']:.3f}")
        print(f"  ROUGE-1 F1: {best_result['rouge1_f1']:.3f}")
        print(f"  Semantic Sim: {best_result['semantic_similarity']:.3f}")
        print(f"  Domain Score: {best_result['domain_score']:.3f}")
        print()
    
    # Calculate averages
    avg_results = {}
    for key in all_results[0].keys():
        if key != 'strategy':
            avg_results[f'avg_{key}'] = np.mean([r[key] for r in all_results])
    
    return {
        'individual_results': all_results,
        'average_results': avg_results,
        'best_summaries': best_summaries
    }

def print_advanced_results(results: Dict):
    """Print comprehensive advanced results"""
    print("\n" + "=" * 100)
    print("ADVANCED PSYCHOLOGICAL SUMMARY EVALUATION RESULTS")
    print("=" * 100)
    
    avg = results['average_results']
    
    print(f"\nOVERALL PERFORMANCE METRICS:")
    print("-" * 60)
    print(f"Advanced Combined Score:    {avg['avg_combined_score']:.4f}")
    print(f"Semantic Similarity:        {avg['avg_semantic_similarity']:.4f}")
    print(f"Domain-Specific Accuracy:   {avg['avg_domain_score']:.4f}")
    
    print(f"\nTRADITIONAL METRICS:")
    print("-" * 60)
    print(f"BLEU-1:     {avg['avg_bleu1']:.4f}")
    print(f"BLEU-2:     {avg['avg_bleu2']:.4f}")
    print(f"ROUGE-1 F1: {avg['avg_rouge1_f1']:.4f}")
    print(f"ROUGE-2 F1: {avg['avg_rouge2_f1']:.4f}")
    print(f"ROUGE-L F1: {avg['avg_rougeL_f1']:.4f}")
    
    print(f"\nADVANCED PERFORMANCE ASSESSMENT:")
    print("-" * 60)
    
    combined = avg['avg_combined_score']
    semantic = avg['avg_semantic_similarity']
    domain = avg['avg_domain_score']
    
    if combined > 0.5:
        print("EXCELLENT: Outstanding performance across all metrics")
    elif combined > 0.4:
        print("GOOD: Strong performance with minor optimization opportunities")
    elif combined > 0.3:
        print("FAIR: Moderate performance, targeted improvements needed")
    else:
        print("POOR: Significant enhancements required")
    
    if domain > 0.4:
        print("Strong psychology domain knowledge and terminology usage")
    elif domain > 0.25:
        print(" Moderate domain knowledge, some terminology gaps")
    else:
        print("Limited psychology-specific terminology and concepts")
    
    if semantic > 0.4:
        print("High semantic alignment with professional standards")
    else:
        print("Semantic alignment needs improvement")

# Example usage
if __name__ == "__main__":
    test_cases = [
        {
            'text': "I always feel anxious about work presentations and think everyone will judge me negatively. I tend to assume the worst will happen and that I'll embarrass myself in front of colleagues.",
            'personality': "Neuroticism: High (0.8), Extraversion: Low (0.3), Openness: Medium (0.6), Agreeableness: High (0.7), Conscientiousness: High (0.8)",
            'emotions': "Anxiety: 0.8, Fear: 0.6, Nervousness: 0.7, Self-doubt: 0.6",
            'distortions': "Mind Reading: 0.9, Catastrophizing: 0.7, Fortune Telling: 0.6"
        }
    ]
    
    reference_summaries = [
        """## PSYCHOLOGICAL ASSESSMENT
        • High conscientiousness drives perfectionist tendencies and detailed preparation behaviors
        • Elevated neuroticism manifests as presentation anxiety and social evaluation fears  
        • Low extraversion creates discomfort with public speaking and social exposure situations
        • High agreeableness leads to excessive concern about others' opinions and judgments
        
        ## THERAPEUTIC RECOMMENDATIONS
        • Cognitive restructuring for mind reading and catastrophizing distortions using CBT protocols
        • Systematic desensitization for presentation anxiety management and exposure therapy
        • Self-compassion training to reduce perfectionist self-criticism and emotional regulation skills
        
        ## CAREER ALIGNMENT  
        Research Analyst: Leverages high conscientiousness and analytical skills while minimizing presentation demands
        Technical Writer: Utilizes attention to detail and structured thinking in low-pressure environment
        Quality Assurance Specialist: Applies perfectionist traits constructively with clear evaluation criteria"""
    ]
    
    results = advanced_evaluation(test_cases, reference_summaries)
    print_advanced_results(results)