import time
import psutil
import numpy as np
from transformers import pipeline
from sklearn.metrics import precision_recall_fscore_support, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

class CognitiveDistortionEvaluator:
    def __init__(self):
        self.labels = [
            "Catastrophizing",
            "Mind Reading", 
            "Overgeneralization",
            "Labeling",
            "Should Statements",
            "Black-and-White Thinking"
        ]
        self.classifier = None
        self.evaluation_results = {}
        
    def initialize_model(self):
        """Initialize the zero-shot classification model"""
        print("Initializing BART-large-MNLI model...")
        start_time = time.time()
        
        try:
            self.classifier = pipeline(
                "zero-shot-classification", 
                model="facebook/bart-large-mnli",
                device=-1  # Use CPU, change to 0 for GPU
            )
            init_time = time.time() - start_time
            print(f"Model initialized successfully in {init_time:.2f}s")
            return init_time
        except Exception as e:
            print(f"Model initialization failed: {e}")
            return None
    
    def detect_distortions(self, text, threshold=0.5):
        """Detect cognitive distortions in text"""
        result = self.classifier(text, candidate_labels=self.labels, multi_label=True)
        predictions = {
            label: round(score, 2)
            for label, score in zip(result["labels"], result["scores"])
            if score > threshold
        }
        return predictions, result
    
    def create_test_dataset(self):
        """Create comprehensive test dataset with known distortions"""
        test_cases = [
            # Catastrophizing examples
            ("This will be a complete disaster", ["Catastrophizing"]),
            ("I'll never recover from this failure", ["Catastrophizing", "Overgeneralization"]),
            ("Everything is ruined now", ["Catastrophizing", "Overgeneralization"]),
            
            # Mind Reading examples  
            ("They think I'm stupid", ["Mind Reading"]),
            ("Everyone is judging me", ["Mind Reading", "Overgeneralization"]),
            ("She hates me, I can tell", ["Mind Reading"]),
            
            # Overgeneralization examples
            ("I always mess things up", ["Overgeneralization"]),
            ("Nothing ever goes right for me", ["Overgeneralization"]),
            ("I never do anything correctly", ["Overgeneralization"]),
            
            # Labeling examples
            ("I'm such an idiot", ["Labeling"]),
            ("I'm a complete failure", ["Labeling"]),
            ("I'm worthless", ["Labeling"]),
            
            # Should Statements examples
            ("I should be perfect at everything", ["Should Statements"]),
            ("I must never make mistakes", ["Should Statements"]),
            ("I should always be happy", ["Should Statements"]),
            
            # Black-and-White Thinking examples
            ("If I'm not the best, I'm the worst", ["Black-and-White Thinking"]),
            ("Either I succeed completely or I'm a failure", ["Black-and-White Thinking"]),
            ("This is either perfect or terrible", ["Black-and-White Thinking"]),
            
            # Mixed distortions
            ("I always ruin everything and everyone thinks I'm terrible", 
             ["Overgeneralization", "Mind Reading", "Catastrophizing"]),
            ("I should be perfect and since I'm not, I'm worthless",
             ["Should Statements", "Labeling", "Black-and-White Thinking"]),
            
            # Neutral/Healthy examples (should detect nothing)
            ("I made a mistake, but I can learn from it", []),
            ("This is challenging, but I'll do my best", []),
            ("I'm having a difficult day today", []),
            ("I feel disappointed about this outcome", []),
        ]
        
        return test_cases
    
    def evaluate_accuracy(self, test_cases, threshold=0.5):
        """Evaluate model accuracy on test dataset"""
        print(f"\nEvaluating accuracy with threshold={threshold}")
        print("="*60)
        
        results = []
        correct_predictions = 0
        total_predictions = 0
        
        precision_scores = defaultdict(list)
        recall_scores = defaultdict(list)
        
        for i, (text, true_labels) in enumerate(test_cases):
            predictions, full_result = self.detect_distortions(text, threshold)
            predicted_labels = list(predictions.keys())
            
            # Calculate metrics for this example
            true_set = set(true_labels)
            pred_set = set(predicted_labels)
            
            # Exact match accuracy
            exact_match = true_set == pred_set
            if exact_match:
                correct_predictions += 1
            
            # Per-label precision and recall
            for label in self.labels:
                if label in true_set and label in pred_set:
                    precision_scores[label].append(1.0)  # True positive
                    recall_scores[label].append(1.0)
                elif label in true_set and label not in pred_set:
                    recall_scores[label].append(0.0)  # False negative
                elif label not in true_set and label in pred_set:
                    precision_scores[label].append(0.0)  # False positive
                elif label not in true_set and label not in pred_set:
                    precision_scores[label].append(1.0)  # True negative
                    recall_scores[label].append(1.0)
            
            results.append({
                'text': text[:50] + "..." if len(text) > 50 else text,
                'true_labels': true_labels,
                'predicted_labels': predicted_labels,
                'predictions': predictions,
                'exact_match': exact_match,
                'confidence_scores': {label: score for label, score in 
                                    zip(full_result["labels"], full_result["scores"])}
            })
            
            total_predictions += 1
            
            # Print sample results
            if i < 5:
                status = "Good" if exact_match else "Bad"
                print(f"{status} '{text[:40]}...'")
                print(f"   True: {true_labels}")
                print(f"   Pred: {predicted_labels}")
                print(f"   Conf: {predictions}")
                print()
        
        exact_match_accuracy = correct_predictions / total_predictions
        
        # Calculate average precision and recall per label
        label_metrics = {}
        for label in self.labels:
            if precision_scores[label]:
                avg_precision = np.mean(precision_scores[label])
                avg_recall = np.mean(recall_scores[label])
                f1 = 2 * (avg_precision * avg_recall) / (avg_precision + avg_recall) if (avg_precision + avg_recall) > 0 else 0
                label_metrics[label] = {
                    'precision': avg_precision,
                    'recall': avg_recall,
                    'f1': f1
                }
        
        return {
            'exact_match_accuracy': exact_match_accuracy,
            'label_metrics': label_metrics,
            'detailed_results': results
        }
    
    def evaluate_threshold_sensitivity(self, test_cases):
        """Evaluate performance across different confidence thresholds"""
        print("\nThreshold Sensitivity Analysis")
        print("="*60)
        
        thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
        threshold_results = []
        
        for threshold in thresholds:
            accuracy_result = self.evaluate_accuracy(test_cases, threshold)
            
            # Calculate overall metrics
            all_precisions = [metrics['precision'] for metrics in accuracy_result['label_metrics'].values()]
            all_recalls = [metrics['recall'] for metrics in accuracy_result['label_metrics'].values()]
            all_f1s = [metrics['f1'] for metrics in accuracy_result['label_metrics'].values()]
            
            avg_precision = np.mean(all_precisions) if all_precisions else 0
            avg_recall = np.mean(all_recalls) if all_recalls else 0
            avg_f1 = np.mean(all_f1s) if all_f1s else 0
            
            threshold_results.append({
                'threshold': threshold,
                'exact_match_accuracy': accuracy_result['exact_match_accuracy'],
                'avg_precision': avg_precision,
                'avg_recall': avg_recall,
                'avg_f1': avg_f1
            })
            
            print(f"Threshold {threshold}: Exact={accuracy_result['exact_match_accuracy']:.3f}, "
                  f"Precision={avg_precision:.3f}, Recall={avg_recall:.3f}, F1={avg_f1:.3f}")
        
        # Find optimal threshold
        optimal_threshold = max(threshold_results, key=lambda x: x['avg_f1'])
        print(f"\nOptimal threshold: {optimal_threshold['threshold']} (F1={optimal_threshold['avg_f1']:.3f})")
        
        return threshold_results, optimal_threshold
    
    def evaluate_performance_efficiency(self):
        """Evaluate computational performance and efficiency"""
        print("\nPerformance & Efficiency Analysis")
        print("="*60)
        
        # Memory usage before processing
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Speed test with varying text lengths
        test_texts = [
            "Short text",
            "This is a medium length text that contains multiple sentences and should take slightly longer to process.",
            "This is a very long text that contains many sentences and words and should demonstrate how the model performs with longer inputs. It includes multiple thoughts and ideas that might contain various cognitive distortions or patterns that the model needs to analyze carefully." * 3
        ]
        
        performance_results = []
        
        for i, text in enumerate(test_texts):
            times = []
            
            # Run multiple trials
            for _ in range(10):
                start_time = time.time()
                predictions, _ = self.detect_distortions(text)
                end_time = time.time()
                times.append(end_time - start_time)
            
            avg_time = np.mean(times)
            std_time = np.std(times)
            
            performance_results.append({
                'text_length': len(text),
                'avg_time_ms': avg_time * 1000,
                'std_time_ms': std_time * 1000,
                'words': len(text.split())
            })
            
            print(f"Text Length {len(text):4d} chars ({len(text.split()):3d} words): "
                  f"{avg_time*1000:.2f}±{std_time*1000:.2f}ms")
        
        # Memory usage after processing
        final_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_usage = final_memory - initial_memory
        
        print(f"\nMemory Usage: {final_memory:.1f} MB (increased by {memory_usage:.1f} MB)")
        
        # Throughput calculation
        avg_time_per_prediction = np.mean([r['avg_time_ms'] for r in performance_results]) / 1000
        throughput = 1 / avg_time_per_prediction
        
        print(f"Average Throughput: {throughput:.1f} predictions/second")
        
        return {
            'performance_results': performance_results,
            'memory_usage_mb': final_memory,
            'memory_increase_mb': memory_usage,
            'throughput_per_second': throughput
        }
    
    def evaluate_edge_cases(self):
        """Test model on challenging edge cases"""
        print("\nEdge Case Analysis")
        print("="*60)
        
        edge_cases = [
            # Ambiguous cases
            ("I'm not sure if this will work out", "Ambiguous - could be realistic or catastrophizing"),
            
            # Subtle distortions
            ("I tend to make mistakes sometimes", "Subtle - mild overgeneralization"),
            
            # Multiple overlapping distortions
            ("I always mess up important things and everyone must think I'm incompetent", 
             "Multiple distortions"),
            
            # Positive but potentially distorted
            ("I must be perfect in everything I do", "Positive tone but distorted thinking"),
            
            # Very short text
            ("I'm terrible", "Very brief"),
            
            # Mixed emotions
            ("I'm happy about the promotion but worried I'll fail", "Mixed emotions"),
            
            # Cultural/contextual
            ("In my culture, we should always respect elders", "Cultural context"),
            
            # Sarcasm/irony
            ("Oh great, another perfect day", "Potential sarcasm"),
        ]
        
        edge_results = []
        for text, description in edge_cases:
            predictions, full_result = self.detect_distortions(text)
            
            edge_results.append({
                'text': text,
                'description': description,
                'predictions': predictions,
                'top_scores': dict(zip(full_result["labels"][:3], full_result["scores"][:3]))
            })
            
            print(f"{description}")
            print(f"   Text: '{text}'")
            print(f"   Detected: {predictions}")
            print(f"   Top 3: {dict(zip(full_result['labels'][:3], [round(s, 3) for s in full_result['scores'][:3]]))}")
            print()
        
        return edge_results
    
    def evaluate_security_considerations(self):
        """Assess security and privacy considerations"""
        print("\nSecurity & Privacy Analysis")
        print("="*60)
        
        security_tests = [
            # Input validation
            ("", "Empty string"),
            ("A" * 10000, "Very long input"),
            ("Special chars: @#$%^&*()_+", "Special characters"),
            ("SQL injection attempt: DROP TABLE users;", "Potential injection"),
            
            # Sensitive content
            ("I want to hurt myself badly", "Self-harm content"),
            ("Personal info: John Smith, 123-45-6789", "Personal information"),
            
            # Adversarial examples  
            ("This is catastrophizing but not really catastrophizing", "Adversarial confusion"),
        ]
        
        security_results = []
        
        for text, test_type in security_tests:
            try:
                start_time = time.time()
                predictions, _ = self.detect_distortions(text[:1000])  # Limit length
                processing_time = time.time() - start_time
                
                security_results.append({
                    'test_type': test_type,
                    'text_preview': text[:50] + "..." if len(text) > 50 else text,
                    'processed_successfully': True,
                    'processing_time': processing_time,
                    'predictions': predictions
                })
                
                print(f"{test_type}: Processed successfully ({processing_time:.3f}s)")
                
            except Exception as e:
                security_results.append({
                    'test_type': test_type,
                    'text_preview': text[:50] + "..." if len(text) > 50 else text,
                    'processed_successfully': False,
                    'error': str(e),
                    'predictions': None
                })
                
                print(f"{test_type}: Failed - {str(e)}")
        
        # Privacy considerations
        print(f"\nPrivacy Considerations:")
        print(f"   • No data is stored by the model")
        print(f"   • Processing happens locally (if using local deployment)")
        print(f"   • Sensitive content detection capability exists")
        print(f"   • No user identification or tracking")
        
        return security_results
    
    def generate_comprehensive_report(self, test_cases):
        """Generate comprehensive evaluation report"""
        print("\n" + "="*80)
        print("COMPREHENSIVE COGNITIVE DISTORTION DETECTION EVALUATION")
        print("="*80)
        
        # 1. Model initialization
        init_time = self.initialize_model()
        if not init_time:
            return None
        
        # 2. Accuracy evaluation
        accuracy_results = self.evaluate_accuracy(test_cases)
        
        # 3. Threshold sensitivity
        threshold_results, optimal_threshold = self.evaluate_threshold_sensitivity(test_cases)
        
        # 4. Performance evaluation
        performance_results = self.evaluate_performance_efficiency()
        
        # 5. Edge case testing
        edge_results = self.evaluate_edge_cases()
        
        # 6. Security assessment
        security_results = self.evaluate_security_considerations()
        
        # 7. Generate final assessment
        self.generate_final_assessment(
            accuracy_results, optimal_threshold, performance_results, 
            edge_results, security_results, init_time
        )
        
        return {
            'accuracy': accuracy_results,
            'threshold_analysis': threshold_results,
            'performance': performance_results,
            'edge_cases': edge_results,
            'security': security_results,
            'initialization_time': init_time
        }
    
    def generate_final_assessment(self, accuracy_results, optimal_threshold, 
                                performance_results, edge_results, security_results, init_time):
        """Generate final comprehensive assessment"""
        print("\n" + "="*80)
        print("FINAL SYSTEM ASSESSMENT")
        print("="*80)
        
        # Effectiveness Assessment
        exact_match_acc = accuracy_results['exact_match_accuracy']
        avg_f1 = optimal_threshold['avg_f1']
        
        print(f"EFFECTIVENESS ASSESSMENT:")
        print(f"   Exact Match Accuracy: {exact_match_acc:.3f} ({exact_match_acc:.1%})")
        print(f"   Average F1-Score: {avg_f1:.3f}")
        print(f"   Optimal Threshold: {optimal_threshold['threshold']}")
        
        # Performance by distortion type
        print(f"\n   Performance by Distortion Type:")
        for label, metrics in accuracy_results['label_metrics'].items():
            print(f"     {label:20}: P={metrics['precision']:.3f}, R={metrics['recall']:.3f}, F1={metrics['f1']:.3f}")
        
        # Efficiency Assessment
        throughput = performance_results['throughput_per_second']
        memory_usage = performance_results['memory_usage_mb']
        
        print(f"\nEFFICIENCY ASSESSMENT:")
        print(f"   Model Initialization: {init_time:.2f}s")
        print(f"   Average Throughput: {throughput:.1f} predictions/second")
        print(f"   Memory Usage: {memory_usage:.1f} MB")
        
        avg_latency = 1000 / throughput
        print(f"   Average Latency: {avg_latency:.1f}ms per prediction")
        
        # Security Assessment
        security_success_rate = sum(1 for r in security_results if r['processed_successfully']) / len(security_results)
        
        print(f"\nSECURITY & ROBUSTNESS:")
        print(f"   Security Test Pass Rate: {security_success_rate:.1%}")
        print(f"   Input Validation: Robust to various input types")
        print(f"   Privacy: No data retention, local processing capable")
        
        # Overall Scoring
        effectiveness_score = (exact_match_acc + avg_f1) / 2
        efficiency_score = min(1.0, throughput / 10)  # Normalize to 10 pred/sec = 1.0
        security_score = security_success_rate
        
        overall_score = (effectiveness_score + efficiency_score + security_score) / 3
        
        print(f"\nOVERALL SYSTEM SCORES:")
        print(f"   Effectiveness Score: {effectiveness_score:.3f}/1.000")
        print(f"   Efficiency Score: {efficiency_score:.3f}/1.000") 
        print(f"   Security Score: {security_score:.3f}/1.000")
        print(f"   Overall System Score: {overall_score:.3f}/1.000")
        
        # Recommendations
        print(f"\nRECOMMENDATIONS:")
        
        if effectiveness_score < 0.7:
            print(f"   • Consider fine-tuning threshold (current optimal: {optimal_threshold['threshold']})")
            print(f"   • Evaluate additional training data for underperforming categories")
        
        if efficiency_score < 0.8:
            print(f"   • Consider model optimization for faster inference")
            print(f"   • Implement batch processing for multiple texts")
        
        print(f"   • Deploy with confidence thresholds for uncertain predictions")
        print(f"   • Implement logging for monitoring edge cases")
        print(f"   • Consider ensemble methods for improved accuracy")
        
        # Use Case Recommendations
        print(f"\nDEPLOYMENT RECOMMENDATIONS:")
        if overall_score >= 0.8:
            print(f"   Production-ready for clinical decision support tools")
            print(f"   Suitable for real-time mental health applications")
        elif overall_score >= 0.6:
            print(f"   Suitable for screening tools with human oversight")
            print(f"   Good for research and development applications")
        else:
            print(f"   Requires significant improvement before production use")
            print(f"   Consider alternative approaches or additional training")
        
        print(f"\nKEY LIMITATIONS:")
        print(f"   • Zero-shot approach may miss context-specific distortions")
        print(f"   • Binary classification loses severity/intensity information")
        print(f"   • Cultural and individual differences not accounted for")
        print(f"   • Requires careful threshold tuning for different use cases")

# Usage
if __name__ == "__main__":
    evaluator = CognitiveDistortionEvaluator()
    test_cases = evaluator.create_test_dataset()
    
    results = evaluator.generate_comprehensive_report(test_cases)
    
    if results:
        print(f"\n Evaluation completed successfully!")
        print(f"Check the detailed results above for comprehensive analysis.")
    else:
        print(f"\nEvaluation failed. Check model initialization.")