import sqlite3
import pandas as pd
import os
from flask import send_file, redirect, url_for, flash, make_response
# Ensure the database directory exists
os.makedirs("database", exist_ok=True)

DB_PATH = "database/applicants.db"

def init_db():
    """Initializes the SQLite database and creates the applicants table."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS applicants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            text_input TEXT,
            emotion TEXT,
            personality TEXT,
            distortion TEXT,
            summary TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """)

def save_applicant(name, email, text, emotion, personality, distortion, summary):
    """Inserts a new applicant record into the database."""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
        INSERT INTO applicants (name, email, text_input, emotion, personality, distortion, summary)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            name,
            email,
            text,
            emotion,
            personality,
            str(distortion),
            summary
        ))

def get_all_applicants():
    """Returns all applicant records in a DataFrame (most recent first)."""
    with sqlite3.connect(DB_PATH) as conn:
        return pd.read_sql(
            "SELECT * FROM applicants ORDER BY timestamp DESC",
            conn
        )

def delete_applicant(applicant_id):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM applicants WHERE id = ?", (applicant_id,))

def export_applicants_csv():
    df = get_all_applicants()
    return df.to_csv(index=False)

def delete_all():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM applicants")
    
def get_applicant_by_id(applicant_id):
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.execute("SELECT * FROM applicants WHERE id = ?", (applicant_id,))
        row = cursor.fetchone()
        return dict(row) if row else None


def add_role_suggestion_column():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("ALTER TABLE applicants ADD COLUMN role_suggestion TEXT")
