import os
import requests

# Set the API key correctly
OPENROUTER_API_KEY = "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"

def run_agent_response(user_question, chat_history, summary, personality, emotion, distortion, history=None):
    # Build system prompt using the NLP model outputs
    system_prompt = f"""
You are a helpful AI assistant designed to help hiring managers, psychologists, and recruiters understand a candidate based on their CV and writing.

You have been given the following analysis of a candidate:

🧠 Personality Analysis:
{personality}

❤️ Emotion Analysis:
{emotion}

🧠 Cognitive Distortion Analysis:
{distortion}

📝 Summary:
{summary}

Use these insights to answer follow-up questions in detail, as if you're a psychological or behavioral expert.

If the user asks for clarification, analysis, or feedback, base your answer strictly on this context. If uncertain, state that more information is needed.
    """

    # Build the messages
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_question}
    ]

    # Set headers for OpenRouter
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "HTTP-Referer": "http://localhost:5000",  # Replace with your domain if hosted
        "X-Title": "PsyMind-Hire AI",
        "Content-Type": "application/json"
    }

    # Set payload
    payload = {
        "model": "openai/gpt-4o-mini",  # Use a consistent model
        "messages": messages,
        "temperature": 0.7
    }

    try:
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions", 
            json=payload, 
            headers=headers
        )
        
        if response.status_code == 200:
            return response.json()["choices"][0]["message"]["content"]
        else:
            return f"❌ Error: {response.status_code} - {response.text}"
            
    except Exception as e:
        print("Agent error:", e)
        return "❌ Error while connecting to the agent. Please try again later."