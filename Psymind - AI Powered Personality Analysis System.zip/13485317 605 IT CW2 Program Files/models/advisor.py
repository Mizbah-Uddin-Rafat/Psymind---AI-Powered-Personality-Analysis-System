from langchain_community.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain

# Initialize the advisor
def get_advisor_chain(api_key):
    llm = ChatOpenAI(
        model_name="openai/gpt-4o-mini",
        openai_api_key="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",
        base_url="https://openrouter.ai/api/v1"
    )

    memory = ConversationBufferMemory()
    conversation = ConversationChain(llm=llm, memory=memory, verbose=False)
    return conversation
