from transformers import pipeline

classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli")

labels = [
    "Catastrophizing",
    "Mind Reading",
    "Overgeneralization",
    "Labeling",
    "Should Statements",
    "Black-and-White Thinking"
]

def detect_distortions(text):
    result = classifier(text, candidate_labels=labels, multi_label=True)
    predictions = {
        label: round(score, 2)
        for label, score in zip(result["labels"], result["scores"])
        if score > 0.5  # you can adjust this threshold
    }
    return predictions

text = "This world is hell"
#print(detect_distortions(text))