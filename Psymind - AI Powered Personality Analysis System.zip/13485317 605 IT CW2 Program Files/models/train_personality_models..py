import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib
import os

df = pd.read_csv('data/mbti_1.csv')

# Parse Big Five traits from MBTI type
def mbti_to_ocean(mbti):
    return {
        'extroversion': 1 if mbti[0] == 'E' else 0,
        'openness': 1 if mbti[1] == 'N' else 0,
        'agreeableness': 1 if mbti[2] == 'F' else 0,
        'conscientiousness': 1 if mbti[3] == 'J' else 0,
    }

# Create label columns
traits = ['extroversion', 'openness', 'agreeableness', 'conscientiousness']
for trait in traits:
    df[trait] = df['type'].apply(lambda mbti: mbti_to_ocean(mbti)[trait])

# Clean posts
df['posts'] = df['posts'].str.replace(r'\|\|\|', ' ', regex=True).str.lower()

# Vectorize text
vectorizer = TfidfVectorizer(max_features=3000)
X = vectorizer.fit_transform(df['posts'])
joblib.dump(vectorizer, 'models/mbti_vectorizer.pkl')

# Train and save model for each trait
for trait in traits:
    y = df[trait]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LogisticRegression(max_iter=1000)
    model.fit(X_train, y_train)
    joblib.dump(model, f'models/{trait}_mbti_model.pkl')
    
    y_pred = model.predict(X_test)
    print(f"Trained and saved model for: {trait}")
    print("Classification Report:")
    print(classification_report(y_test, y_pred))