import sys
import os
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)
from models.emotion_detector import classify_emotion
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
from transformers import pipeline
import random

class EmotionModelEvaluator:
    def __init__(self, classifier_func):
        self.classifier_func = classifier_func
        self.results = {}
        
    def create_test_dataset(self):
        """Create a diverse test dataset with known emotions"""
        test_data = [
            # Joy/Happy
            ("I just got promoted at work! This is the best day ever!", "joy"),
            ("The sunset was absolutely beautiful tonight", "joy"),
            ("I love spending time with my family", "joy"),
            
            # Sadness
            ("I miss my grandmother so much since she passed away", "sadness"),
            ("The movie ending made me cry", "sadness"),
            ("I feel lonely and isolated lately", "sadness"),
            
            # Anger
            ("This traffic is making me furious!", "anger"),
            ("I can't believe they canceled my flight again", "anger"),
            ("The customer service was absolutely terrible", "anger"),
            
            # Fear
            ("I'm terrified of the job interview tomorrow", "fear"),
            ("Walking alone at night makes me anxious", "fear"),
            ("The thunderstorm is really scary", "fear"),
            
            # Surprise
            ("I never expected to win the lottery!", "surprise"),
            ("What a plot twist in that movie!", "surprise"),
            ("I was shocked to see my old friend", "surprise"),
            
            # Disgust
            ("The food was absolutely revolting", "disgust"),
            ("I hate the smell of cigarettes", "disgust"),
            ("That behavior is completely unacceptable", "disgust"),
            
            # Neutral
            ("I went to the store and bought milk", "neutral"),
            ("The meeting is scheduled for 2 PM", "neutral"),
            ("It's Tuesday today", "neutral"),
        ]
        
        return pd.DataFrame(test_data, columns=['text', 'true_emotion'])
    
    def evaluate_accuracy(self, test_df):
        """Calculate basic accuracy metrics"""
        predictions = []
        confidences = []
        
        for text in test_df['text']:
            result = self.classifier_func(text)
            predictions.append(result['top_emotion'])
            confidences.append(result['confidence'])
        
        test_df['predicted_emotion'] = predictions
        test_df['confidence'] = confidences
        
        accuracy = accuracy_score(test_df['true_emotion'], test_df['predicted_emotion'])
        
        self.results['accuracy'] = accuracy
        self.results['test_data'] = test_df
        
        return accuracy, test_df
    
    def detailed_classification_report(self, test_df):
        """Generate detailed classification metrics"""
        report = classification_report(
            test_df['true_emotion'], 
            test_df['predicted_emotion'],
            output_dict=True
        )
        
        self.results['classification_report'] = report
        return report
    
    def confusion_matrix_analysis(self, test_df):
        """Create and analyze confusion matrix"""
        cm = confusion_matrix(test_df['true_emotion'], test_df['predicted_emotion'])
        labels = sorted(test_df['true_emotion'].unique())
        
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=labels, yticklabels=labels)
        plt.title('Emotion Classification Confusion Matrix')
        plt.ylabel('True Emotion')
        plt.xlabel('Predicted Emotion')
        plt.tight_layout()
        plt.show()
        
        return cm, labels
    
    def confidence_analysis(self, test_df):
        """Analyze prediction confidence patterns"""
        # Average confidence per emotion
        conf_by_emotion = test_df.groupby('true_emotion')['confidence'].agg(['mean', 'std'])
        
        # Confidence vs accuracy
        correct_predictions = test_df['true_emotion'] == test_df['predicted_emotion']
        correct_conf = test_df[correct_predictions]['confidence'].mean()
        incorrect_conf = test_df[~correct_predictions]['confidence'].mean()
        
        plt.figure(figsize=(12, 5))
        
        # Plot 1: Confidence by emotion
        plt.subplot(1, 2, 1)
        conf_by_emotion['mean'].plot(kind='bar')
        plt.title('Average Confidence by True Emotion')
        plt.ylabel('Confidence Score')
        plt.xticks(rotation=45)
        
        # Plot 2: Confidence comparison
        plt.subplot(1, 2, 2)
        plt.bar(['Correct', 'Incorrect'], [correct_conf, incorrect_conf])
        plt.title('Confidence: Correct vs Incorrect Predictions')
        plt.ylabel('Average Confidence')
        
        plt.tight_layout()
        plt.show()
        
        return {
            'conf_by_emotion': conf_by_emotion,
            'correct_conf': correct_conf,
            'incorrect_conf': incorrect_conf
        }
    
    def edge_case_testing(self):
        """Test model on challenging edge cases"""
        edge_cases = [
            # Mixed emotions
            "I'm happy about the promotion but sad to leave my team",
            
            # Sarcasm
            "Oh great, another meeting. Just what I needed today.",
            
            # Subtle emotions
            "I suppose that's fine",
            
            # Ambiguous context
            "It's over",
            
            # Very short text
            "Wow",
            
            # Emotional intensity variations
            "I'm slightly annoyed",
            "I'm absolutely furious",
            
            # Cultural expressions
            "That's lit!",
            "I'm shook",
        ]
        
        edge_results = []
        for text in edge_cases:
            result = self.classifier_func(text)
            edge_results.append({
                'text': text,
                'predicted_emotion': result['top_emotion'],
                'confidence': result['confidence'],
                'all_scores': result['all_scores']
            })
        
        return pd.DataFrame(edge_results)
    
    def robustness_testing(self):
        """Test model robustness with text variations"""
        base_text = "I am very happy today"
        variations = [
            base_text,  # Original
            base_text.upper(),  # ALL CAPS
            base_text.lower(),  # lowercase
            "i am very happy today",  # no caps
            "I'm very happy today",  # contraction
            "I am extremely happy today",  # intensity change
            "Today I am very happy",  # word order
            "I am very, very happy today",  # repetition
            "I am very happy today!",  # punctuation
            "I am very happy today!!!",  # multiple punctuation
        ]
        
        robustness_results = []
        for text in variations:
            result = self.classifier_func(text)
            robustness_results.append({
                'text': text,
                'predicted_emotion': result['top_emotion'],
                'confidence': result['confidence']
            })
        
        return pd.DataFrame(robustness_results)
    
    def run_full_evaluation(self):
        """Run complete evaluation suite"""
        print("Starting Emotion Classification Model Evaluation")
        print("=" * 60)
        
        # 1. Basic accuracy testing
        print("\n1. Creating test dataset and measuring accuracy...")
        test_df = self.create_test_dataset()
        accuracy, results_df = self.evaluate_accuracy(test_df)
        print(f"   Overall Accuracy: {accuracy:.3f}")
        
        # 2. Detailed metrics
        print("\n2. Generating detailed classification report...")
        report = self.detailed_classification_report(results_df)
        
        # 3. Confusion matrix
        print("\n3. Creating confusion matrix...")
        cm, labels = self.confusion_matrix_analysis(results_df)
        
        # 4. Confidence analysis
        print("\n4. Analyzing prediction confidence...")
        conf_analysis = self.confidence_analysis(results_df)
        
        # 5. Edge cases
        print("\n5. Testing edge cases...")
        edge_results = self.edge_case_testing()
        print("   Edge case results:")
        for _, row in edge_results.iterrows():
            print(f"   '{row['text'][:30]}...' → {row['predicted_emotion']} ({row['confidence']:.3f})")
        
        # 6. Robustness testing
        print("\n6. Testing robustness...")
        robustness_results = self.robustness_testing()
        print("   Robustness test completed")
        
        # Summary
        print("\n" + "=" * 60)
        print("EVALUATION SUMMARY")
        print("=" * 60)
        print(f"Overall Accuracy: {accuracy:.3f}")
        print(f"Average Confidence (Correct): {conf_analysis['correct_conf']:.3f}")
        print(f"Average Confidence (Incorrect): {conf_analysis['incorrect_conf']:.3f}")
        
        # Store all results
        self.results.update({
            'edge_cases': edge_results,
            'robustness': robustness_results,
            'confidence_analysis': conf_analysis
        })
        
        return self.results

# Usage example
if __name__ == "__main__":
    # Initialize evaluator
    evaluator = EmotionModelEvaluator(classify_emotion)
    
    # Run evaluation
    results = evaluator.run_full_evaluation()
    
    # Access specific results
    print(f"\nModel achieved {results['accuracy']:.1%} accuracy on test set")
    
    # Print detailed classification report
    print("\nDetailed Classification Report:")
    report = results['classification_report']
    for emotion, metrics in report.items():
        if emotion not in ['accuracy', 'macro avg', 'weighted avg']:
            print(f"{emotion:>10}: Precision={metrics['precision']:.3f}, "
                  f"Recall={metrics['recall']:.3f}, F1={metrics['f1-score']:.3f}")

evaluator = EmotionModelEvaluator(classify_emotion)
results = evaluator.run_full_evaluation()