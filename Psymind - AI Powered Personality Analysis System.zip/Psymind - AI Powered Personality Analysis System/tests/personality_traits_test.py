import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, accuracy_score, precision_recall_fscore_support
from sklearn.metrics import confusion_matrix, roc_auc_score
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
import time
import psutil
import os

class MBTIOceanEvaluator:
    def __init__(self, csv_path='data/mbti_1.csv'):
        self.csv_path = csv_path
        self.traits = ['extroversion', 'openness', 'agreeableness', 'conscientiousness']
        self.models = {}
        self.vectorizer = None
        self.evaluation_results = {}
        
    def load_and_prepare_data(self):
        """Load and prepare the MBTI dataset"""
        print("Loading and preparing data...")
        self.df = pd.read_csv(self.csv_path)
        
        # Data quality assessment
        print(f"Dataset size: {self.df.shape}")
        print(f"Missing values: {self.df.isnull().sum().sum()}")
        print(f"Unique MBTI types: {self.df['type'].nunique()}")
        
        return self.df
    
    def mbti_to_ocean(self, mbti):
        """Convert MBTI type to OCEAN traits"""
        return {
            'extroversion': 1 if mbti[0] == 'E' else 0,
            'openness': 1 if mbti[1] == 'N' else 0,
            'agreeableness': 1 if mbti[2] == 'F' else 0,
            'conscientiousness': 1 if mbti[3] == 'J' else 0,
        }
    
    def prepare_features_and_labels(self):
        """Prepare features and labels for training"""
        # Create label columns
        for trait in self.traits:
            self.df[trait] = self.df['type'].apply(lambda mbti: self.mbti_to_ocean(mbti)[trait])
        
        # Clean posts
        self.df['posts'] = self.df['posts'].str.replace(r'\|\|\|', ' ', regex=True).str.lower()
        
        # Analyze class distribution
        print("\nClass Distribution Analysis:")
        for trait in self.traits:
            dist = self.df[trait].value_counts()
            print(f"{trait}: High={dist[1]} ({dist[1]/len(self.df):.1%}), Low={dist[0]} ({dist[0]/len(self.df):.1%})")
        
        return self.df
    
    def evaluate_text_preprocessing(self):
        """Evaluate text preprocessing effectiveness"""
        print("\nText Preprocessing Analysis:")
        
        # Analyze text length distribution
        text_lengths = self.df['posts'].str.len()
        print(f"Average text length: {text_lengths.mean():.0f} characters")
        print(f"Text length range: {text_lengths.min()}-{text_lengths.max()}")
        
        # Sample original vs processed
        sample_idx = 0
        original = self.df.iloc[sample_idx]['posts']
        print(f"\nSample processed text (first 200 chars):")
        print(f"'{original[:200]}...'")
        
        return {
            'avg_length': text_lengths.mean(),
            'length_std': text_lengths.std(),
            'min_length': text_lengths.min(),
            'max_length': text_lengths.max()
        }
    
    def evaluate_vectorization(self):
        """Evaluate TF-IDF vectorization effectiveness"""
        print("\nVectorization Analysis:")
        
        # Create vectorizer
        vectorizer = TfidfVectorizer(max_features=3000)
        X = vectorizer.fit_transform(self.df['posts'])
        
        print(f"Vocabulary size: {len(vectorizer.vocabulary_)}")
        print(f"Feature matrix shape: {X.shape}")
        print(f"Sparsity: {(1 - X.nnz / (X.shape[0] * X.shape[1])):.3f}")
        
        # Top features by TF-IDF score
        feature_names = vectorizer.get_feature_names_out()
        tfidf_scores = X.sum(axis=0).A1
        top_features = sorted(zip(feature_names, tfidf_scores), key=lambda x: x[1], reverse=True)[:10]
        
        print(f"\nTop 10 TF-IDF features:")
        for feature, score in top_features:
            print(f"  {feature}: {score:.2f}")
        
        self.vectorizer = vectorizer
        return X, {
            'vocab_size': len(vectorizer.vocabulary_),
            'sparsity': (1 - X.nnz / (X.shape[0] * X.shape[1])),
            'top_features': top_features[:5]
        }
    
    def train_and_evaluate_models(self, X):
        """Train and evaluate models for each trait"""
        print("\nModel Training and Evaluation:")
        print("=" * 50)
        
        results = {}
        
        for trait in self.traits:
            print(f"\nTraining model for: {trait}")
            y = self.df[trait]
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=y
            )
            
            # Train model with timing
            start_time = time.time()
            model = LogisticRegression(max_iter=1000, random_state=42)
            model.fit(X_train, y_train)
            training_time = time.time() - start_time
            
            # Predictions with timing
            start_time = time.time()
            y_pred = model.predict(X_test)
            y_pred_proba = model.predict_proba(X_test)[:, 1]
            prediction_time = time.time() - start_time
            
            # Calculate metrics
            accuracy = accuracy_score(y_test, y_pred)
            precision, recall, f1, _ = precision_recall_fscore_support(y_test, y_pred, average='binary')
            auc_score = roc_auc_score(y_test, y_pred_proba)
            
            # Cross-validation
            cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='accuracy')
            
            results[trait] = {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'auc': auc_score,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'training_time': training_time,
                'prediction_time': prediction_time,
                'model': model
            }
            
            print(f"  Accuracy: {accuracy:.3f}")
            print(f"  F1-Score: {f1:.3f}")
            print(f"  AUC: {auc_score:.3f}")
            print(f"  CV Score: {cv_scores.mean():.3f} (±{cv_scores.std():.3f})")
            print(f"  Training time: {training_time:.3f}s")
            
            self.models[trait] = model
        
        return results
    
    def evaluate_prediction_quality(self, model_results):
        """Evaluate prediction quality and consistency"""
        print("\nPrediction Quality Analysis:")
        
        # Test on sample texts
        test_texts = [
            "I love meeting new people and going to parties! I'm always excited about new experiences.",
            "I prefer quiet evenings at home with a good book. I think carefully before making decisions.",
            "I'm always trying new things and love creative projects. I care deeply about others' feelings.",
            "I'm very organized and always plan ahead. I stick to my schedules and deadlines."
        ]
        
        expected_patterns = [
            {'extroversion': 'High', 'openness': 'High'},  # Social, adventurous
            {'extroversion': 'Low', 'conscientiousness': 'High'},  # Introverted, planned
            {'openness': 'High', 'agreeableness': 'High'},  # Creative, caring
            {'conscientiousness': 'High'}  # Organized
        ]
        
        print("\nSample Predictions:")
        consistency_score = 0
        total_expectations = 0
        
        for i, text in enumerate(test_texts):
            vec = self.vectorizer.transform([text])
            predictions = {}
            confidences = {}
            
            for trait in self.traits:
                pred = self.models[trait].predict(vec)[0]
                confidence = max(self.models[trait].predict_proba(vec)[0])
                predictions[trait] = "High" if pred == 1 else "Low"
                confidences[trait] = confidence
            
            print(f"\nText {i+1}: '{text[:50]}...'")
            for trait in self.traits:
                print(f"  {trait}: {predictions[trait]} (confidence: {confidences[trait]:.3f})")
            
            # Check consistency with expectations
            if i < len(expected_patterns):
                for trait, expected in expected_patterns[i].items():
                    total_expectations += 1
                    if predictions[trait] == expected:
                        consistency_score += 1
        
        logical_consistency = consistency_score / total_expectations if total_expectations > 0 else 0
        print(f"\nLogical Consistency Score: {logical_consistency:.3f}")
        
        return logical_consistency
    
    def evaluate_efficiency_metrics(self):
        """Evaluate system efficiency"""
        print("\nEfficiency Analysis:")
        
        # Memory usage
        process = psutil.Process()
        memory_mb = process.memory_info().rss / 1024 / 1024
        
        # Model size estimation
        total_model_size = 0
        for trait in self.traits:
            # Estimate model size (coefficients + intercept)
            model = self.models[trait]
            model_params = model.coef_.size + model.intercept_.size
            total_model_size += model_params
        
        # Vectorizer size
        vectorizer_size = len(self.vectorizer.vocabulary_) * 8  # Rough estimate
        
        print(f"Memory usage: {memory_mb:.1f} MB")
        print(f"Total model parameters: {total_model_size:,}")
        print(f"Vectorizer size estimate: {vectorizer_size/1024:.1f} KB")
        
        # Speed test
        test_text = "I am a very social person who loves new experiences."
        
        start_time = time.time()
        for _ in range(100):  # 100 predictions
            vec = self.vectorizer.transform([test_text])
            for trait in self.traits:
                _ = self.models[trait].predict(vec)[0]
        total_time = time.time() - start_time
        
        avg_prediction_time = total_time / 100
        print(f"Average prediction time: {avg_prediction_time*1000:.2f} ms")
        print(f"Predictions per second: {1/avg_prediction_time:.0f}")
        
        return {
            'memory_mb': memory_mb,
            'model_parameters': total_model_size,
            'avg_prediction_ms': avg_prediction_time * 1000,
            'predictions_per_second': 1/avg_prediction_time
        }
    
    def generate_effectiveness_summary(self, model_results, consistency_score):
        """Generate effectiveness summary"""
        print("\n" + "="*60)
        print("EFFECTIVENESS SUMMARY")
        print("="*60)
        
        # Overall accuracy
        avg_accuracy = np.mean([results['accuracy'] for results in model_results.values()])
        avg_f1 = np.mean([results['f1'] for results in model_results.values()])
        avg_auc = np.mean([results['auc'] for results in model_results.values()])
        
        print(f"Average Accuracy: {avg_accuracy:.3f}")
        print(f"Average F1-Score: {avg_f1:.3f}")
        print(f"Average AUC: {avg_auc:.3f}")
        print(f"Logical Consistency: {consistency_score:.3f}")
        
        print("\nPer-Trait Performance:")
        for trait, results in model_results.items():
            print(f"  {trait:15}: Acc={results['accuracy']:.3f}, F1={results['f1']:.3f}, AUC={results['auc']:.3f}")
        
        # Identify strengths and weaknesses
        best_trait = max(model_results.keys(), key=lambda t: model_results[t]['f1'])
        worst_trait = min(model_results.keys(), key=lambda t: model_results[t]['f1'])
        
        print(f"\nBest performing trait: {best_trait} (F1={model_results[best_trait]['f1']:.3f})")
        print(f"Worst performing trait: {worst_trait} (F1={model_results[worst_trait]['f1']:.3f})")
        
        return {
            'avg_accuracy': avg_accuracy,
            'avg_f1': avg_f1,
            'avg_auc': avg_auc,
            'consistency': consistency_score,
            'best_trait': best_trait,
            'worst_trait': worst_trait
        }
    
    def generate_efficiency_summary(self, efficiency_metrics):
        """Generate efficiency summary"""
        print("\n" + "="*60)
        print("EFFICIENCY SUMMARY")
        print("="*60)
        
        print(f"System Resource Usage:")
        print(f"  Memory: {efficiency_metrics['memory_mb']:.1f} MB")
        print(f"  Model Parameters: {efficiency_metrics['model_parameters']:,}")
        
        print(f"\nPerformance Metrics:")
        print(f"  Prediction Speed: {efficiency_metrics['avg_prediction_ms']:.2f} ms")
        print(f"  Throughput: {efficiency_metrics['predictions_per_second']:.0f} predictions/second")
        
        # Efficiency rating
        speed_rating = "Excellent" if efficiency_metrics['avg_prediction_ms'] < 10 else \
                      "Good" if efficiency_metrics['avg_prediction_ms'] < 50 else "Fair"
        memory_rating = "Excellent" if efficiency_metrics['memory_mb'] < 100 else \
                       "Good" if efficiency_metrics['memory_mb'] < 500 else "Fair"
        
        print(f"\nEfficiency Ratings:")
        print(f"  Speed: {speed_rating}")
        print(f"  Memory Usage: {memory_rating}")
        
        return {
            'speed_rating': speed_rating,
            'memory_rating': memory_rating
        }
    
    def run_comprehensive_evaluation(self):
        """Run complete evaluation suite"""
        print("MBTI-to-OCEAN Personality Prediction System Evaluation")
        print("="*60)
        
        # 1. Load and prepare data
        self.load_and_prepare_data()
        self.prepare_features_and_labels()
        
        # 2. Evaluate preprocessing
        text_stats = self.evaluate_text_preprocessing()
        
        # 3. Evaluate vectorization
        X, vectorization_stats = self.evaluate_vectorization()
        
        # 4. Train and evaluate models
        model_results = self.train_and_evaluate_models(X)
        
        # 5. Evaluate prediction quality
        consistency_score = self.evaluate_prediction_quality(model_results)
        
        # 6. Evaluate efficiency
        efficiency_metrics = self.evaluate_efficiency_metrics()
        
        # 7. Generate summaries
        effectiveness_summary = self.generate_effectiveness_summary(model_results, consistency_score)
        efficiency_summary = self.generate_efficiency_summary(efficiency_metrics)
        
        # 8. Final assessment
        self.generate_final_assessment(effectiveness_summary, efficiency_summary)
        
        return {
            'effectiveness': effectiveness_summary,
            'efficiency': efficiency_summary,
            'model_results': model_results,
            'text_stats': text_stats,
            'vectorization_stats': vectorization_stats
        }
    
    def generate_final_assessment(self, effectiveness, efficiency):
        """Generate final system assessment"""
        print("\n" + "="*60)
        print("FINAL SYSTEM ASSESSMENT")
        print("="*60)
        
        # Overall effectiveness score (0-1)
        effectiveness_score = (effectiveness['avg_f1'] + effectiveness['consistency']) / 2
        
        # Overall efficiency score (0-1)
        speed_score = 1.0 if efficiency['speed_rating'] == "Excellent" else \
                     0.7 if efficiency['speed_rating'] == "Good" else 0.4
        memory_score = 1.0 if efficiency['memory_rating'] == "Excellent" else \
                      0.7 if efficiency['memory_rating'] == "Good" else 0.4
        efficiency_score = (speed_score + memory_score) / 2
        
        print(f"Effectiveness Score: {effectiveness_score:.3f}/1.000")
        print(f"Efficiency Score: {efficiency_score:.3f}/1.000")
        print(f"Overall System Score: {(effectiveness_score + efficiency_score)/2:.3f}/1.000")
        
        # Recommendations
        print(f"\nStrengths:")
        print(f"  • Fast inference speed ({efficiency['speed_rating'].lower()})")
        print(f"  • Memory efficient ({efficiency['memory_rating'].lower()})")
        print(f"  • Reasonable accuracy across traits (avg F1={effectiveness['avg_f1']:.3f})")
        
        print(f"\nLimitations:")
        print(f"  • MBTI-to-OCEAN mapping may not reflect true personality psychology")
        print(f"  • Binary classification loses nuance in personality traits")
        print(f"  • Performance varies across traits ({effectiveness['worst_trait']} weakest)")
        
        print(f"\nRecommendations:")
        if effectiveness_score < 0.7:
            print(f"  • Consider additional feature engineering or model architectures")
            print(f"  • Evaluate alternative personality frameworks")
        if efficiency_score < 0.7:
            print(f"  • Optimize model size and inference pipeline")
        print(f"  • Implement confidence thresholds for uncertain predictions")
        print(f"  • Consider ensemble methods for improved accuracy")

# Usage
if __name__ == "__main__":
    try:
        # Try to find the CSV file in common locations
        possible_paths = [
            'data/mbti_1.csv',
            '../data/mbti_1.csv',
            'mbti_1.csv',
            'c:/605 IT - Project/data/mbti_1.csv'
        ]
        
        csv_path = None
        for path in possible_paths:
            if os.path.exists(path):
                csv_path = path
                break
        
        if csv_path is None:
            print("Error: Could not find mbti_1.csv file")
            print("Please ensure the file exists in one of these locations:")
            for path in possible_paths:
                print(f"  - {path}")
            exit(1)
        
        print(f"Using CSV file: {csv_path}")
        evaluator = MBTIOceanEvaluator(csv_path)
        results = evaluator.run_comprehensive_evaluation()
        
    except FileNotFoundError as e:
        print(f"Error: Could not find required file - {e}")
        print("Make sure mbti_1.csv exists in the data/ directory")
    except Exception as e:
        print(f"Error running evaluation: {e}")
        print("Make sure you have all required packages installed:")
        print("pip install pandas scikit-learn matplotlib seaborn psutil")