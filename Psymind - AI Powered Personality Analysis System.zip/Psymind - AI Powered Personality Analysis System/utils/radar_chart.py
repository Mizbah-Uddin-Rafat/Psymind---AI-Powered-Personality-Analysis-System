import matplotlib.pyplot as plt
import numpy as np

def plot_ocean_radar(traits: dict, save_path="static/ocean_radar.png"):
    labels = ['Openness', 'Conscientiousness', 'Extraversion', 'Agreeableness', 'Neuroticism']
    # Convert 'High'/'Low' to numeric scores
    scores = [
        1 if traits.get('openness', 'Low') == 'High' else 0,
        1 if traits.get('conscientiousness', 'Low') == 'High' else 0,
        1 if traits.get('extroversion', 'Low') == 'High' else 0,
        1 if traits.get('agreeableness', 'Low') == 'High' else 0,
        1 if traits.get('neuroticism', 'Low') == 'High' else 0,
    ]
    
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    scores += scores[:1]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    ax.fill(angles, scores, color='skyblue', alpha=0.6)
    ax.plot(angles, scores, color='blue', linewidth=2)
    ax.set_yticklabels([])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)
    ax.set_title("Big Five Personality Radar", fontsize=14)
    
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
