from io import BytesIO

# Import your function
from cv_parser import extract_text_from_file, extract_info  # Replace with actual filename

# Simulate an uploaded file (PDF or DOCX)
with open(r"C:\605 IT - Project\models\cv-template.pdf", "rb") as f:
    uploaded_file = BytesIO(f.read())
    uploaded_file.name = "cv_template.pdf"  # Add name attribute for compatibility

# Extract text
text = extract_text_from_file(uploaded_file)

# Extract structured info
info = extract_info(text)

# Print results
print("Extracted Name:", info["name"])
print("Extracted Email:", info["email"])
print("Extracted Text Preview:", text[:500].encode("ascii", "ignore").decode())
  # First 500 characters
