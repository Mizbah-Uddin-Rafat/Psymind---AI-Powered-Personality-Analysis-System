import re
from pdfminer.high_level import extract_text as extract_pdf_text
from docx import Document

def extract_text_from_file(uploaded_file):
    file_type = uploaded_file.name.lower()
    if file_type.endswith(".pdf"):
        with open("temp_cv.pdf", "wb") as f:
            f.write(uploaded_file.read())
        return extract_pdf_text("temp_cv.pdf")
    elif file_type.endswith(".docx"):
        doc = Document(uploaded_file)
        return "\n".join([p.text for p in doc.paragraphs])
    else:
        return "Unsupported file type"

def extract_info(text):
    email = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.\w+\b', text, re.IGNORECASE)
    name = text.split('\n')[0].strip()
    return {
        "name": name,
        "email": email.group(0) if email else "Not found",
        "text": text
    }
