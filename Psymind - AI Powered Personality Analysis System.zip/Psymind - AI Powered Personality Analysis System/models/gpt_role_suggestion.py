from openai import OpenAI

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="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"
)

def get_role_suggestion_openrouter(personality, emotions, distortions):
    messages = [
        {
            "role": "system",
            "content": "You are a career advisor. Recommend ideal job roles based on personality, emotions, and cognitive patterns."
        },
        {
            "role": "user",
            "content": f"""Personality Traits: {personality}
Emotions: {emotions}
Cognitive Distortions: {distortions}

What job roles would suit this person best and why?"""
        }
    ]

    try:
        response = client.chat.completions.create(
            model="openai/gpt-4o-mini",
            messages=messages,
            temperature=0.7
        )
        return response.choices[0].message.content.strip()

    except Exception as e:
        return f"Error generating role suggestion: {e}"
