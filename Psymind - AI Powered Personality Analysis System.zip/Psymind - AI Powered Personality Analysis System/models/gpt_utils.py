from openai import OpenAI

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="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"  # Replace with your actual key
)

def generate_summary_with_openrouter(text, personality, emotions, distortions):
    messages = [
        {
            "role": "system",
            "content": (
                "You are an expert psychologist and career advisor. "
                "Based on a person's emotional profile, Big Five personality traits, and cognitive distortions, "
                "provide a well-structured psychological summary and career recommendations. "
                "Format your response with clear sections, bullet points, and proper organization."
            )
        },
        {
            "role": "user",
            "content": f"""TEXT INPUT:
{text}

PERSONALITY TRAITS:
{personality}

EMOTIONAL PROFILE:
{emotions}

COGNITIVE DISTORTIONS:
{distortions}

Please provide a structured response with the following format:

## PSYCHOLOGICAL PROFILE SUMMARY

Provide a comprehensive overview using bullet points for:
• Key personality strengths
• Dominant emotional patterns  
• Areas for development
• Overall psychological assessment

## CAREER RECOMMENDATIONS

List 3-5 ideal career roles with the following structure for each:

**[Role Title]**
• Why it fits: [Brief explanation of personality alignment]
• Key strengths utilized: [Specific traits that match]
• Growth opportunity: [How this role supports development]

Make sure to use bullet points, clear headings, and organized formatting."""
        }
    ]

    try:
        response = client.chat.completions.create(
            model="openai/gpt-4o-mini",
            messages=messages,
            temperature=0.7,
            max_tokens=1500
        )
        return response.choices[0].message.content.strip()

    except Exception as e:
        return f"OpenRouter Error: {e}"