import joblib
import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

model_dir = os.path.dirname(__file__)
traits = ['extroversion', 'openness', 'agreeableness', 'conscientiousness']

# Load vectorizer and models
vectorizer = joblib.load(os.path.join(model_dir, 'mbti_vectorizer.pkl'))
models = {
    trait: joblib.load(os.path.join(model_dir, f"{trait}_mbti_model.pkl"))
    for trait in traits
}

def predict_ocean_traits(text: str) -> dict:
    vec = vectorizer.transform([text])
    return {
        trait: "High" if model.predict(vec)[0] == 1 else "Low"
        for trait, model in models.items()
    }
    


text = "I am a very calm person, always smiling and love peace."
#result = predict_ocean_traits(text)

#print(result)
# {'extroversion': 'High', 'openness': 'High', 'agreeableness': 'High', 'conscientiousness': 'High'}
from utils.radar_chart import plot_ocean_radar

traits = predict_ocean_traits(text)
plot_ocean_radar(traits)