from transformers import pipeline

classifier = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base", return_all_scores=True)

def classify_emotion(text: str):
    scores = classifier(text)[0]
    top = max(scores, key=lambda x: x["score"])
    return {
        "top_emotion": top["label"],
        "confidence": round(top["score"], 4),
        "all_scores": {s["label"]: round(s["score"], 4) for s in scores}
    }

#text = "I am not feeling so well"
#result = classify_emotion(text)
#print(result)